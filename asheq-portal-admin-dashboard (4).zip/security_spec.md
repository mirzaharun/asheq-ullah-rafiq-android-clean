# Security Specification & Threat Model (`asheq-ullah-rafiq-digital-p`)

## 1. Data Invariants
1. **Default-Deny Baseline**: Every unspecified collection or document path is denied by `match /{document=**} { allow read, write: if false; }`.
2. **Trusted Admin Identity (`admins/{uid}`)**: Authentication alone never confers administrative privileges. An authenticated user is recognized as an administrator only when `/databases/$(database)/documents/admins/$(request.auth.uid)` exists with `active == true`, `uid == request.auth.uid`, and `role in ['super_admin', 'editor', 'application_manager']`.
3. **No Self-Promotion**: Ordinary authenticated users cannot create, update, or delete any document in `admins/{uid}` or set `role` / `isAdmin` fields on `users/{uid}` (self-writes on `users/{uid}` are strictly limited to non-privileged profile fields).
4. **PII & Private Citizen Data Protection**: Unauthenticated users and non-admin citizens can never read `blood_donors` (contains `phone`), `applications`, `citizen_grievances`, `appointments`, `feedback`, `general_feedback`, `data_removal_requests`, `sms_logs`, `users` (other users or list), `admins`, or `audit_logs`. Signed-in citizens may submit new requests (`status == 'Submitted'`, no `officialResponse` or `statusHistory`) and submit active poll votes (`voteCounts` map only).
5. **Android Public Content Preservation**: Public portal collections (`development_projects`, `notices`, `watercraft_schedules`, `tide_schedules`, `udc_centers` [active], `office_contact`, `data_sources` [enabled], `config` [`home` writable by Content Managers; settings strictly Super Admin], `profile_info`, and published `gallery_items`) remain readable without authentication using their exact Android field names. `supporter_cards` remains permanently denied.
6. **Immutable Logs**: `audit_logs/{logId}` and `sms_logs/{logId}` entries can never be updated or deleted.
7. **Status Transition Integrity**: Citizen-submitted requests must initialize at `Submitted`; application statuses are constrained to the approved workflow (`Submitted`, `Under Review`, `Additional Information Required`, `Forwarded to Relevant Office`, `In Progress`, `Resolved`, `Rejected`), and terminal states (`Resolved`, `Rejected`) are locked against modification by non-super-admins. Data removal requests transition only via Super Admin review (`PENDING` -> `APPROVED` / `REJECTED`).

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated PII Read**: Unauthenticated client requests `getDocs(collection(db, 'blood_donors'))` -> MUST return `PERMISSION_DENIED`.
2. **Unauthenticated Citizen Application Read**: Unauthenticated client requests `getDocs(collection(db, 'applications'))` -> MUST return `PERMISSION_DENIED`.
3. **Unauthenticated Grievance / Appointment Read**: Unauthenticated client requests `getDocs(collection(db, 'citizen_grievances'))` or `appointments` -> MUST return `PERMISSION_DENIED`.
4. **Unauthenticated Admin Enumeration**: Unauthenticated client requests `getDocs(collection(db, 'admins'))` -> MUST return `PERMISSION_DENIED`.
5. **Self-Promotion Attack (`admins/{myUid}`)**: Ordinary signed-in user attempts `setDoc(doc(db, 'admins', myUid), { uid: myUid, email: 'user@example.com', role: 'super_admin', active: true })` -> MUST return `PERMISSION_DENIED`.
6. **Self-Promotion via `users/{myUid}`**: Ordinary signed-in user attempts `setDoc(doc(db, 'users', myUid), { uid: myUid, role: 'super_admin', isAdmin: true })` -> MUST return `PERMISSION_DENIED`.
7. **Shadow Field Injection on `development_projects`**: `editor` attempts `setDoc` with valid fields plus `{ isAdminOverride: true }` -> MUST return `PERMISSION_DENIED` (`hasOnly` check).
8. **Role Boundary Violation (`editor` -> `applications`)**: Active `editor` attempts to update `applications/app1` status -> MUST return `PERMISSION_DENIED`.
9. **Role Boundary Violation (`application_manager` -> `notices`)**: Active `application_manager` attempts to create/edit `notices/N3` -> MUST return `PERMISSION_DENIED`.
10. **Terminal State Bypass (`application_manager` modifying `Resolved` application)**: `application_manager` attempts to revert an application whose existing status is `Resolved` -> MUST return `PERMISSION_DENIED`.
11. **Audit Log Tampering / Impersonation**: `editor` attempts to create `audit_logs/log1` with `actorUid: 'someone-else'` or `updateDoc` / `deleteDoc` on an existing audit log -> MUST return `PERMISSION_DENIED`.
12. **Resource / ID Poisoning**: `editor` attempts to write `notices/<1500-char-id>` or `titleBn` exceeding maxLength -> MUST return `PERMISSION_DENIED`.
