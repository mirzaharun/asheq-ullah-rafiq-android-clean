# Pre-Hardening Firestore Security Rules Inspection & Backup Guide

## Inspection Environment Note
- **Firebase Project ID**: `asheq-ullah-rafiq-digital-p`
- **Firestore Database ID**: `ai-studio-android-ashequll-1eaee2e6-a2b4-4b98-a823-0ccf82508943`
- **Workspace State**: Separate Web Admin Panel project (not the Android repository). No local `firestore.rules` file existed in this workspace, and `firebase login:list` reported no authenticated CLI account in this container (`No authorized accounts, run "firebase login"`).

## Observed Live Behavior Before Hardening
Non-destructive read checks (`getDocs` / `getCountFromServer`) executed from the Web Admin workspace against `ai-studio-android-ashequll-1eaee2e6-a2b4-4b98-a823-0ccf82508943` without authentication returned:
- `development_projects`: **READ ALLOWED** (10 documents)
- `gallery_items`: **READ ALLOWED** (8 documents)
- `notices`: **READ ALLOWED** (2 documents)
- `blood_donors` (contains `phone` numbers): **READ ALLOWED** (4 documents)
- `watercraft_schedules`: **READ ALLOWED** (4 documents)
- `tide_schedules`: **READ ALLOWED** (1 document)
- `applications`: **READ ALLOWED** (0 documents)
- `citizen_grievances`: **READ ALLOWED** (0 documents)
- `appointments`: **READ ALLOWED** (0 documents)
- `users`: **READ ALLOWED** (0 documents)
- `admins`: **READ ALLOWED** (0 documents)
- `audit_logs`: **READ ALLOWED** (0 documents)

This confirms the existing deployed rules currently allow unauthenticated reads across all inspected collections.

## Mandatory Manual Backup Step Before Deployment
Because the container lacks `firebase login` credentials to pull the remote rules text automatically, capture the exact deployed rules text into `backups/firestore.rules.original` before deploying `firestore.rules`:

1. Open **Firebase Console** -> Project `asheq-ullah-rafiq-digital-p` -> **Firestore Database** -> select database `ai-studio-android-ashequll-1eaee2e6-a2b4-4b98-a823-0ccf82508943` -> **Rules** tab.
2. Copy the complete currently published rules text into `backups/firestore.rules.original`.
3. Alternatively, from an authenticated local workstation with Firebase CLI:
   ```bash
   firebase login
   firebase use asheq-ullah-rafiq-digital-p
   firebase firestore:rules:get > backups/firestore.rules.original
   ```
4. Keep `backups/firestore.rules.original` committed or archived for immediate rollback.
