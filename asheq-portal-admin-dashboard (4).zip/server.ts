import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

// 1. AI Smart Assistant Chat Proxy Route (Never exposes API Key to client/Android)
app.post('/api/assistant/chat', async (req, res) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({
        error: 'Gemini API Key is not configured in server environment (GEMINI_API_KEY).',
      });
    }

    const { prompt, message, history, systemInstruction } = req.body ?? {};
    const userText =
      typeof prompt === 'string' && prompt.trim()
        ? prompt.trim()
        : typeof message === 'string' && message.trim()
        ? message.trim()
        : '';

    if (!userText) {
      return res.status(400).json({ error: 'Valid prompt or message string is required.' });
    }

    const contents: string | Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> =
      Array.isArray(history) && history.length > 0
        ? [
            ...history
              .filter(
                (item): item is { role?: string; text?: string; content?: string } =>
                  typeof item === 'object' && item !== null
              )
              .map((item) => ({
                role: (item.role === 'model' || item.role === 'assistant' ? 'model' : 'user') as
                  | 'user'
                  | 'model',
                parts: [
                  {
                    text: String(item.text ?? item.content ?? '').slice(0, 4000),
                  },
                ],
              }))
              .filter((turn) => turn.parts[0].text.length > 0),
            { role: 'user' as const, parts: [{ text: userText.slice(0, 4000) }] },
          ]
        : userText.slice(0, 4000);

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents,
      config: {
        systemInstruction:
          typeof systemInstruction === 'string' && systemInstruction.trim()
            ? systemInstruction.trim()
            : "You are the official AI Smart Assistant for the Asheq Ullah Rafiq Digital Portal (Maheshkhali - Kutubdia, Cox's Bazar-2). Answer politely in fluent Bengali and English with factual, helpful, and citizen-friendly information regarding public notices, development projects, digital citizen services, and coastal maritime updates.",
      },
    });

    return res.json({
      reply: response.text || '',
      model: 'gemini-4-hydrogen',
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    console.error('Server AI Chat Error:', err);
    return res.status(500).json({
      error: err instanceof Error ? err.message : 'AI generation error',
    });
  }
});

// 2. Health check route
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    portal: 'Asheq Ullah Rafiq Digital Portal',
    timestamp: new Date().toISOString(),
  });
});

// 3. Vite Middleware in dev or static files in production
async function startServer() {
  const PORT = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  if (isProd) {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Asheq Ullah Rafiq Portal running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
