import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  CheckCircle2,
  Database,
  FileCode2,
  Info,
  Loader2,
  ShieldCheck,
} from 'lucide-react';
import {
  PermissionErrorBanner,
  StatusBadge,
} from '../components/crud/CrudPrimitives';
import { getModuleByKey } from '../config/modules';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { canAccessModule, getRoleLabel } from '../services/authService';
import {
  fetchCollectionCount,
  fetchSingletonDoc,
  formatFirestoreError,
} from '../services/firestoreCrud';
import { UnauthorizedPage } from './UnauthorizedPage';

export const ModuleWorkspacePage: React.FC = () => {
  const { moduleKey = '' } = useParams<{ moduleKey: string }>();
  const { adminUser } = useAuth();
  const { lang, t } = useLanguage();

  const mod = getModuleByKey(moduleKey);

  const [loading, setLoading] = useState(true);
  const [docCount, setDocCount] = useState<number | null>(null);
  const [singletonExists, setSingletonExists] = useState<boolean | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const hasAccess = mod ? canAccessModule(adminUser?.role, mod) : false;

  useEffect(() => {
    if (!mod || !hasAccess) {
      setLoading(false);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setErrorMsg(null);
    setDocCount(null);
    setSingletonExists(null);

    const run = async () => {
      try {
        if (mod.storageKind === 'singleton' && mod.singletonDocId) {
          const snap = await fetchSingletonDoc(mod.collection, mod.singletonDocId);
          if (!cancelled) {
            setSingletonExists(Boolean(snap));
            setDocCount(snap ? 1 : 0);
          }
        } else {
          const count = await fetchCollectionCount(mod.collection);
          if (!cancelled) {
            setDocCount(count);
          }
        }
      } catch (err) {
        if (!cancelled) {
          setErrorMsg(formatFirestoreError(err, lang));
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    void run();

    return () => {
      cancelled = true;
    };
  }, [mod, hasAccess, lang]);

  if (!mod) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center max-w-lg mx-auto mt-8">
        <h2 className="text-lg font-bold text-slate-900">
          {t('মডিউল পাওয়া যায়নি', 'Module Not Found')}
        </h2>
        <p className="text-sm text-slate-500 mt-1">
          {t(
            'অনুরোধকৃত মডিউল রুটটি পোর্টাল রেজিস্ট্রিতে নেই।',
            'The requested module key does not exist in the portal registry.'
          )}
        </p>
        <Link
          to="/dashboard"
          className="inline-flex items-center gap-2 mt-5 px-4 py-2 rounded-xl bg-emerald-800 text-white text-sm font-semibold"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>{t('ড্যাশবোর্ডে ফিরুন', 'Back to Dashboard')}</span>
        </Link>
      </div>
    );
  }

  if (!hasAccess) {
    return <UnauthorizedPage />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <Link to="/dashboard" className="hover:text-emerald-700 font-medium">
              {t('ড্যাশবোর্ড', 'Dashboard')}
            </Link>
            <span>/</span>
            <span className="font-mono text-slate-700">{mod.collection}</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">
            {lang === 'bn' ? mod.titleBn : mod.titleEn}
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            {lang === 'bn' ? mod.descriptionBn : mod.descriptionEn}
          </p>
        </div>

        <StatusBadge
          status={
            mod.storageKind === 'singleton'
              ? t('সিঙ্গেলটন ডকুমেন্ট', 'Singleton Document')
              : t('কালেকশন মডিউল', 'Collection Module')
          }
        />
      </div>

      {errorMsg && <PermissionErrorBanner message={errorMsg} />}

      {/* Technical Binding Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
            <Database className="h-4 w-4 text-emerald-700" />
            <span>{t('Firestore টার্গেট পাথ', 'Firestore Target Path')}</span>
          </div>
          <p className="mt-2 font-mono text-sm font-bold text-slate-900 break-all">
            /{mod.collection}
            {mod.singletonDocId ? `/${mod.singletonDocId}` : ''}
          </p>
          {mod.mirrorCollection && (
            <p className="mt-1 text-xs text-slate-500 font-mono">
              + /{mod.mirrorCollection}
            </p>
          )}
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
            <CheckCircle2 className="h-4 w-4 text-emerald-700" />
            <span>{t('লাইভ ডকুমেন্ট সংখ্যা', 'Live Firestore Records')}</span>
          </div>
          <div className="mt-2 flex items-center gap-2">
            {loading ? (
              <Loader2 className="h-5 w-5 animate-spin text-emerald-700" />
            ) : (
              <span className="text-2xl font-bold text-slate-900">
                {docCount !== null ? docCount : '—'}
              </span>
            )}
            {mod.storageKind === 'singleton' && singletonExists !== null && (
              <span className="text-xs text-slate-500">
                {singletonExists
                  ? t('(ডকুমেন্ট বিদ্যমান)', '(Document exists)')
                  : t('(এখনো তৈরি হয়নি)', '(Not yet created)')}
              </span>
            )}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
            <ShieldCheck className="h-4 w-4 text-emerald-700" />
            <span>{t('অনুমোদিত RBAC রোলসমূহ', 'Authorized RBAC Roles')}</span>
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {mod.allowedRoles.map((role) => (
              <span
                key={role}
                className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200"
              >
                {getRoleLabel(role, lang)}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Phase 3C Readiness Notice */}
      <div className="bg-white rounded-2xl border border-sky-200 p-6 flex items-start gap-4">
        <div className="h-10 w-10 rounded-xl bg-sky-50 text-sky-700 flex items-center justify-center shrink-0">
          <FileCode2 className="h-5 w-5" />
        </div>
        <div className="space-y-2">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <span>
              {t(
                'ফেজ ৩এ/৩বি স্ট্যাটাস: রুট, RBAC ও Firestore সংযোগ প্রস্তুত',
                'Phase 3A/3B Status: Route, RBAC & Firestore Binding Ready'
              )}
            </span>
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            {t(
              'এই মডিউলের রোল-ভিত্তিক প্রবেশাধিকার যাচাই, সাইডবার নেভিগেশন, নামযুক্ত Firestore ডাটাবেজ সংযোগ এবং অডিট লগ সার্ভিস যুক্ত হয়েছে। অনুমোদনের পর পরবর্তী ধাপে (Phase 3C) এই মডিউলের সম্পূর্ণ ক্রিয়েট/এডিট/ডিলিট (CRUD) ফর্ম ও ফাইল আপলোড যুক্ত করা হবে।',
              'Role-gated routing, sidebar navigation, named Firestore database binding, and audit log plumbing are verified for this module. Interactive Phase 3C CRUD forms, workflow status editors, and Firebase Storage uploads will be attached in Phase 3C upon approval.'
            )}
          </p>
          <div className="pt-1 flex items-center gap-2 text-xs text-slate-500">
            <Info className="h-3.5 w-3.5 text-sky-600" />
            <span>
              {t('মডিউল ক্রম:', 'Module Slot:')} #{mod.order} •{' '}
              {mod.group.toUpperCase()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
